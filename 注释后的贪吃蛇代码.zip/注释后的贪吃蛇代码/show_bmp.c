
#include"main.h"

/*********************************************************************************
函数功能：显示图片函数
函数参数：name：图片ID；  x0：图片x坐标 ；  y0：图片y坐标
返回值：0
*********************************************************************************/
int show_bmp_self(char *name,int x0,int y0)
{
	//打开图片位置
	int fd_bmp = open(name,O_RDONLY);
	//判断是否可以打开图片，如果打不开，则退出程序
	if(fd_bmp == -1)
	{
		printf("open fail\n");
		return -1;
	}
	
	//打开lcd屏
	int fd_lcd = open("/dev/fb0",O_RDWR);  
	//判断是否可以打开lcd屏幕，如果打不开，则退出 
	if(fd_lcd == -1)
	{
		close(fd_bmp);
		printf("open fail\n");
		return -1;
	}
	//设置图片文件偏移量（fd_bmp：图片ID，54：因为图片的头是54字节，SEEK_SET：偏移到当前位置）
	lseek(fd_bmp,54,SEEK_SET);
	//动态申请内存
	unsigned char *s = (unsigned char *)malloc(800*480*3);
	//读取图片
	int a = read(fd_bmp,s,800*480*3);
	//printf("read bmp:%dbit\n",a);
	//将lcd屏文件映射进内存
	int *p = (int *)mmap(NULL,800*480*4,PROT_WRITE|PROT_READ,MAP_SHARED,fd_lcd,0);
	
	int i,j;
	//显示图片算法【可以不需要掌握】
	for(j=y0;j<480&&j<20+y0;j++)
	{
		for(i=x0;i<800&&i<20+x0;i++)
		{
			p[j*800+i] = s[((479-j)*800+i)*3] | s[((479-j)*800+i)*3+1]<<8 | s[((479-j)*800+i)*3+2]<<16;
		}
	}

	

	//关闭图片
	close(fd_bmp);
	//关闭lcd屏幕
	close(fd_lcd);
	//释放掉内存
	free(s);
	//解除一个映射关系
	munmap(p,800*480*4);
	return 0;
}

/*********************************************与上面代码类似*********************************
函数功能：显示图片函数
函数参数：name：图片ID；  x0：图片x坐标 ；  y0：图片y坐标
返回值：0
*********************************************************************************/
int show_bmp_mix(char *name,int x0,int y0,int lx,int ly)
{
	//打开图片
	int fd_bmp = open(name,O_RDONLY);
	//如果打开失败，则退出
	if(fd_bmp == -1)
	{
		printf("open fail\n");
		return -1;
	}
	
	//打开lcd屏幕
	int fd_lcd = open("/dev/fb0",O_RDWR);   
	//如果打开失败，则退出
	if(fd_lcd == -1)
	{
		close(fd_bmp);
		printf("open fail\n");
		return -1;
	}
	//设置图片文件偏移量（fd_bmp：图片ID，54：因为图片的头是54字节，SEEK_SET：偏移到当前位置）
	lseek(fd_bmp,54,SEEK_SET);
	//动态申请内存
	unsigned char *s = (unsigned char *)malloc(lx*ly*3);
	//读取图片
	int a = read(fd_bmp,s,lx*ly*3);
	//printf("read bmp:%dbit\n",a);
	//将lcd屏文件映射进内存
	int *p = (int *)mmap(NULL,800*480*4,PROT_WRITE|PROT_READ,MAP_SHARED,fd_lcd,0);
	
	int i,j;
	//计算显示图片算法
	for(j=0;j<ly&&j<480-y0;j++)
	{
		for(i=0;i<lx&&i<800-x0;i++)
		{
			
			p[(ly-j-1+y0)*800+i+x0] = s[(j*lx+i)*3] | s[(j*lx+i)*3+1]<<8 | s[(j*lx+i)*3+2]<<16;
		}
	}
	//printf("j:%d i:%d\n",j,i);
	

	//关闭图片
	close(fd_bmp);
	//关闭lcd
	close(fd_lcd);
	//释放内存
	free(s);
	//解除一个映射关系
	munmap(p,800*480*4);
	return 0;
}

/*********************************************************************************
函数功能：得分显示函数
函数参数：无
返回值：0
*********************************************************************************/
int score_show(){
	int a1,a2,a3; // 个 十 百
	
	//初始化得分二维数组
	char s[3][10]={0};
	//图片ID
	char *tmp = ".bmp";
	//计算得分
	a1 = score%10;
	a2 = score/10%10;
	a3 = score/100;
	
	printf("score:%d%d%d\n",a3,a2,a1);
	
	//以下是计算得分，以及分数图片ID
	s[0][0] = (char)(a1+48);
	strncat(s[0],tmp,4);
	
	s[1][0] = (char)(a2+48);
	strncat(s[1],tmp,4);
	
	s[2][0] = (char)(a3+48);
	strncat(s[2],tmp,4);
	
	//printf("%s  %s  %s\n",s[2],s[1],s[0]);
	//显示对应的分数图片
	show_bmp_mix(s[2],700,132,20,20);
	show_bmp_mix(s[1],725,132,20,20);
	show_bmp_mix(s[0],750,132,20,20);
	
	
	return 0;
}

/*********************************************************************************
函数功能：速度显示函数
函数参数：无
返回值：0
*********************************************************************************/
int speed_show()
{

	int a = show_set.speed;
	
	//定义一个一维数组，存储速度值
	char s[10]={0};
	//定义一个指针，用来存储图片ID
	char *tmp = ".bmp";
	
	
	s[0] = (char)(a+48);
	//计算图片ID
	strncat(s,tmp,4);
	//显示速度图片
	show_bmp_mix(s,744,190,20,20);
	
	return 0;
}




