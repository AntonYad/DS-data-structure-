

#include"main.h"

//初始化蛇
struct slink * snake_init()
{
	score = 0;
	show_set.speed = 1;
	show_set.dir = 2;
	show_set.stat = 1;
	show_set.lock = 1;
	//显示第一张图片
	show_bmp_mix("./snake.bmp",0,0,800,480);
	//延时5000毫秒
	usleep(1000*5);
	//蛇头初始化位置
	shead = list_init(100,200);
	//显示蛇头、蛇身
	list_show(shead);
	
	//显示游戏画面
	score_show();  
	//延时5000毫秒
	usleep(1000*5);
	//速度显示
	speed_show();
	//返回蛇头
	return shead;
}

//玩游戏
int play_snake()
{
	int lx,ly;
	//调用初始化蛇函数
	snake_init();
	//定义俩个线程变量
	pthread_t id1,id2;
	//创建线程函数
	pthread_create(&id1, NULL, touch_det_p, NULL);
	pthread_create(&id2, NULL, food, NULL);	
	//0操作   2:吃到食物
	int st; //judge:0 no touch self  2:eat food
	while(1)
	{
		//判断暂停状态
		while(show_set.stat == 0 || show_set.lock ==0)
		{ //judge pause status
			usleep(1000*5);
		}		
		//迟到食物，添加蛇身
		st=list_add(shead,show_set.dir);
		//如果蛇操作移动
		if(st == 0){ // move
			//每次移动，会有一点的延时
			list_delate(shead,&lx,&ly);
			//显示蛇图片
			show_bmp_self("./snake.bmp",lx,ly);
			//显示蛇头、蛇身
			list_show(shead);
			//延时/(80+80*0)ms -	(80+80*7)ms		
			usleep(1000*(80+(8-show_set.speed)*70));	//(80+80*0)ms -	(80+80*7)ms		
		}//如果蛇吃到食物	
		else if(st == 2)
		{ //eat food
				//显示蛇头、蛇身
			list_show(shead);
			//初始化食物延时时间为0
			steps = 0; //interruput pthread food sleep
			//延时1000*(80+(8-show_set.speed)*70)
			usleep(1000*(80+(8-show_set.speed)*70)); 
			//显示游戏画面
			int score_show();
		}
		//如果蛇自己吃到自己身上
		else if(st == 1){ //touch self
			//游戏结束
			printf("1:game over!\n");
			//显示结束界面图片
			show_bmp_mix("./over.bmp",170,155,260,70);
			show_bmp_mix("./play.bmp",110,285,100,50);
			show_bmp_mix("./quite.bmp",360,285,100,50);
			show_set.stat = 0;
			show_set.lock = 0;
			// exit(0);	
		}

	}

	return 0;
}