#include"main.h"

/*********************************************************************************
函数功能：获取点击触摸屏位置函数
函数参数：*x：x坐标；   *y：y坐标
返回值：0
*********************************************************************************/
int get_xy(int *x,int *y)
{
	//打开触摸屏
	int fd_touch = open("/dev/input/event0",O_RDONLY);
	//判断是否打开，如果打不开，则退出程序
	if(fd_touch == -1)
	{
		printf("open touch screen fail\n");
		exit(-1);
	}
	
	int i = 0;
	
	while(i != 2)
	{
		//读取触摸屏
		read(fd_touch,&ts,sizeof(ts));
		//如果触摸类型为3
		if(ts.type == 3){
			//触摸屏的值为0
			if(ts.code == 0){
				//将触摸屏的值，赋值给*x
				*x = ts.value;
				i++;//i自加1
			}
			//如果触摸屏类型为1
			else if(ts.code == 1){
				////将触摸屏的值，赋值给*y
				*y = ts.value;
				i++;
				//printf("x:%d y:%d\n",*x,*y);
			}
		}
		
		/* if(ts.type == 1&& ts.value == 0){
			
			break;
		} */
		
	}
	//关闭触摸屏
	close(fd_touch);

	return 0;
}

/*********************************************************************************
函数功能：操作触摸屏函数
函数参数：*set触摸屏操作值
返回值：0
*********************************************************************************/
int touch_det(struct touch *set)
{
	
	int x,y;
	
	get_xy(&x,&y);//获取点击触摸屏位置函数
	
	//如果点击触摸屏位置：  285<y<335 且  110 < x < 210    游戏开始按钮
	if(y>285&&y<=335&&x>110&&x<210)
	{
		printf("play\n");
		int tmp_x,tmp_y;
		//延时一丢丢
		while(list_delate(shead,&tmp_x,&tmp_y) != -1);
		//调用贪吃蛇初始化函数
		snake_init();
		steps = 0;
		//初始化设置标志位为1
		set->stat = 1;
		set->lock = 1;
		goto end;
	}
	//如果点击触摸屏位置：  285<y<335 且  360 < x < 460   QUITE按钮
	if(y>285&&y<=335&&x>360&&x<460)
	{
		printf("quite\n");
		//显示QUITE按钮图片
		show_bmp_mix("./rest.bmp",0,0,800,480);
		//退出
		exit(0);
	}
	//如果标志位为0，则退出程序
	if(set->lock == 0)
	{
		goto end;
	}
	
	//如果点击触摸屏位置：  222<y<278且  642 < x < 692   
	if(y>222&&y<278&&x>642&&x<692)
	{
		//如果当前速度为9
		if(++set->speed == 9 )
		{	//设置当前速度值为8	
			set->speed=8;
		}
		printf("speed +: %d\n",set->speed);
		//调用速度显示函数
		speed_show();
		//退出程序
		goto end;
	}
	//如果点击触摸屏位置：  222<y<278且  725 < x < 775 
	if(y>222&&y<278&&x>725&&x<775)
	{
		//如果当前速度-1为0
		if(--set->speed == 0 ){	
			//设置当前速度值为1	
			set->speed=1;
		}
		printf("speed -: %d\n",set->speed);
		//调用速度显示函数
		speed_show();
		//退出程序
		goto end;
	}
	//如果点击触摸屏位置：  330<y<371且  681 < x < 723
	if(y>330&&y<371&&x>681&&x<723)
	{
		//如果操作方向的值为4
		if(set->dir == 4){
			//退出程序
			goto end;
		}
		else{
			//如果操作方向的值为3
			set->dir = 3;
			//向上
			printf("up\n");
			//退出程序
			goto end;			
		}

	}
	//如果点击触摸屏位置：  400<y<464且  681 < x < 723
	if(y>400&&y<464&&x>681&&x<723)
	{
		//如果操作方向的值为3
		if(set->dir == 3){
			//退出程序
			goto end;
		}
		else{//如果操作方向的值不是3
			//设置方向值为4
			set->dir = 4;
			//向下
			printf("down\n");
			//退出程序
			goto end;			
		}

	}
	//如果点击触摸屏位置：  370<y<420且  624 < x < 671
	if(y>370&&y<420&&x>624&&x<671)
	{
		//如果操作方向的值为2
		if(set->dir == 2){
			//退出程序
			goto end;
		}
		else{//如果操作方向的值不是2
			//设置方向值为1
			set->dir = 1;
			//向左
			printf("left\n");
			//退出程序
			goto end;			
		}
	}
	//如果点击触摸屏位置：  370<y<420且  730 < x < 771
	if(y>370&&y<420&&x>730&&x<771){
		
		//如果操作方向的值为1
		if(set->dir == 1){
			goto end;
		}
		else//如果操作方向的值不是1
		{
			//设置方向值为2
			set->dir = 2;
			//向右
			printf("right\n");
			goto end;			
		}

	}
	//如果点击触摸屏位置：  441<y<480且  624 < x < 675
	if(y>441&&y<=480&&x>624&&x<675)
	{
		printf("puase\n");
		//设置暂停标志位为0	（0表示开始）
		set->stat = 0;
		goto end;
	}
	//如果点击触摸屏位置：  441<y<480且  730 < x < 783
	if(y>441&&y<=480&&x>730&&x<783)
	{
		printf("start\n");
		//设置暂停标志位为1	（1表示暂停）
		set->stat = 1;
	}
	
end:
	
	return 0;//退出程序
}

