
#include"main.h"

/*********************************************************************************
函数功能：检测线程，操作设置蛇移动
函数参数：移动位置
返回值：无
*********************************************************************************/
void *touch_det_p(void *arg)
{ ////the pthread detecting the screan to set the <shw_set> parameters of snake-moving
	
	while(1)
	{
		
		touch_det(&show_set);
	}

}
/*********************************************************************************
函数功能：显示蛇的食物
函数参数：食物的位置
返回值：无
*********************************************************************************/
void *food(void *arg)
{  //pthread: show snake's food
	
	int sx0,sy0;	
	int i;
	//定义随机数种子
	srand((unsigned)time(NULL));	
	while(1)
	{		
		steps = 74; //74:length steps + width steps  600/200+480/20	
		while(show_set.stat == 0 || show_set.lock == 0){ //judge pause status
			usleep(1500*5);
		}
		
		sx0 = (rand()%30)*20;//0<= sx0 <= 600
		sy0 = (rand()%12)*20;//0<= sy0 <= 240
		
		i = list_seek(shead,sx0,sy0);//获取蛇走向，将返回值赋值给i		
		if(i == 1)//如果i == 1
		{
			continue;//跳过本次循环
		}
		else if(i == 2)//如果i == 2
		{
			show_bmp_self("./snake.bmp",sx0,sy0);//显示贪吃蛇的图片
			continue;
		}
		else if(i == 0){//如果i == 0
			
			if(fxy.x0<0&&fxy.y0<0)//判断贪吃蛇x轴和y轴位置，如果都小于0
			{
				fxy.x0 = sx0;//将sx0获取的随机数赋值给fxy.x0
				fxy.y0 = sy0;//将sy0获取的随机数赋值给fxy.y0
			}
			else if(fxy.x0>=0&&fxy.y0>=0)//判断贪吃蛇x轴和y轴位置，如果都大于0
			{
				show_bmp_self("./snake.bmp",fxy.x0,fxy.y0);//显示贪吃蛇的图片
				fxy.x0 = sx0;//将sx0获取的随机数赋值给fxy.x0
				fxy.y0 = sy0;//将sy0获取的随机数赋值给fxy.y0				
			}
			else//如果不满足以上条件的话，程序退出
			{				
				printf("fxy.x0,fxy.y0 set default\n");
				exit(-1);//退出程序
			}			
			show_bmp_mix("./s.bmp",fxy.x0,fxy.y0,20,20);//显示贪吃蛇的图片
		}
		
		while(steps-- > 0)
		{  //如果食物被吃掉，将steps设置为0
			usleep(1000*(80+(8-show_set.speed)*70));  //(step_time)    	
		}	
		
	 }
	
}