#ifndef __MAIN_H_
#define __MAIN_H_



#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/mman.h>
#include<linux/input.h>

#include<string.h>
#include<strings.h>

#include <pthread.h>



int score;

int steps; // for ptshead:food sleep食物延时

/***********************************
定义蛇身结构体链表
x0：蛇身的x坐标
y0：蛇身的y坐标
pre：蛇身上一步
next：蛇身下一步
************************************/
struct slink
{ //snake's bodys
	
	int x0;
	int y0;
	
	struct slink *pre;
	struct slink *next;
};

struct slink * shead;//for pthread:void *food()食物线程

/*************************************************************
定义触摸结构体
speed：速度（由：1 2 3 4 5级）
dir:方向键（左、右、上、下）
stat：位置
lock：游戏结束使用
*************************************************************/
struct touch
{  //snake's set value struct
	
	int speed;//LEVE: 1 2 3 4 5
	
	int dir; //L:1 R:2 U:3 D:4
	
	int stat;	//PUASE: 0 STARET:1  --->lock2
	
	int lock;   // when game over whill be used  --->lock1
};

/*****************************************************************
定义食物位置结构体
x0：x坐标
y0：y坐标
*****************************************************************/
struct food_xy
{  // food position struct
	
	int x0;
	int y0;
	
};

//食物位置
struct food_xy fxy; // food position

//设置蛇的值
struct touch show_set; //snake's set value

//检测线程，设置蛇移动参数
void *touch_det_p(void *arg);//the pthread detecting the screan to set the <shw_set> parameters of snake-moving

//蛇的食物线程
void *food(void *arg);//the pthread showing the snake's food 

//控制游戏函数
int play_snake();//the function control all the game 

//显示自身图片
int show_bmp_self(char *name,int x0,int y0);

int show_bmp_mix(char *name,int x0,int y0,int lx,int ly);
int score_show();
int speed_show();

struct input_event ts;

int get_xy(int *,int *);

int touch_det(struct touch *);

//游戏初始化函数
struct slink * snake_init();


//list  part
struct slink * list_init(int xt,int yt);
int list_add(struct slink * shead,int dir); 
int list_delate(struct slink * shead,int *fx,int *fy);
void list_show(struct slink *shead);
int list_seek(struct slink *shead,int sx,int sy);



#endif