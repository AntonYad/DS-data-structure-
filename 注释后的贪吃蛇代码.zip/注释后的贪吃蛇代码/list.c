#include"main.h"

/*********************************************************************************
函数功能：蛇头初始化的位置函数
函数参数： xt：蛇头坐标 ；  yt：蛇头坐标
返回值：蛇头
*********************************************************************************/
struct slink * list_init(int xt,int yt){ //
	
	//动态申请内存
	struct slink *shead = (struct slink *)malloc(sizeof(struct slink));
	struct slink *s1 = (struct slink *)malloc(sizeof(struct slink));
	struct slink *s2 = (struct slink *)malloc(sizeof(struct slink));
	struct slink *s3 = (struct slink *)malloc(sizeof(struct slink));
	
	//初始化蛇头双向链表
	shead->next = s1;
	shead->pre = s3;
	
	s1->next = s2;
	s1->pre = shead;
	s1->x0 = xt;
	s1->y0 = yt;
	
	s2->next = s3;
	s2->pre = s1;
	s2->x0 = xt-20;
	s2->y0 = yt;
	
	s3->next = shead;
	s3->pre = s2;
	s3->x0 = xt-40;
	s3->y0 = yt;

	return shead;
}

/*********************************************************************************
函数功能：蛇吃到食物，蛇身添加长度函数
函数参数： shead：蛇头； dir：位置
返回值：添加的长度
*********************************************************************************/
int list_add(struct slink * shead,int dir)
{
	
	int i;
	

	//动态申请内存【重新定义一个节点】	
	struct slink *new = (struct slink *)malloc(sizeof(struct slink));
	//将蛇头的下一个节点指向新节点的下一个节点
	new->next = shead->next;

	//方向键操作蛇
	switch(dir)
	{
		
		case 1:
		{
			new->x0 = new->next->x0-20;
			new->y0 = new->next->y0;
			break;
		}
		case 2:
		{
			new->x0 = new->next->x0+20;
			new->y0 = new->next->y0;
			break;
		}
		case 3:
		{
			new->x0 = new->next->x0;
			new->y0 = new->next->y0-20;
			break;
		}
		case 4:
		{
			new->x0 = new->next->x0;
			new->y0 = new->next->y0+20;
			break;
		}
		
		default:
			break;	
	}
	// crash wall judge
	/*if(new->x0<0||new->x0>=620||new->y0<0||new->y0>480){
		printf("0:game over!\n");
		exit(0);
	} */
	
	//
	if(new->x0 < 0)
	{
		//new->x0 += 620;
		 show_bmp_mix("./over.bmp",170,155,260,70);
                        show_bmp_mix("./play.bmp",110,285,100,50);
                        show_bmp_mix("./quite.bmp",360,285,100,50);
     	    //            show_set.stat = 0;
             //           show_set.lock = 0;

			return 0;
	}
	else if(new->x0 >= 620)
	{
		//new->x0 -=620;
		        show_bmp_mix("./over.bmp",170,155,260,70);
                        show_bmp_mix("./play.bmp",110,285,100,50);
                        show_bmp_mix("./quite.bmp",360,285,100,50);
              //          show_set.stat = 0;
                //        show_set.lock = 0;
		return 0;

	}
	
	if(new->y0 < 0)
	{
		//new->y0 += 480;
		 //游戏结束
                        printf("1:game over!\n");
                        //显示结束界面图片
                        show_bmp_mix("./over.bmp",170,155,260,70);
                        show_bmp_mix("./play.bmp",110,285,100,50);
                        show_bmp_mix("./quite.bmp",360,285,100,50);
                  //      show_set.stat = 0;
                    //    show_set.lock = 0;
		return 0;

	}
	else if(new->y0 >=480)
	{
	//	new->y0 -=480;
	 //游戏结束
                        printf("1:game over!\n");
                        //显示结束界面图片
                        show_bmp_mix("./over.bmp",170,155,260,70);
                        show_bmp_mix("./play.bmp",110,285,100,50);
                        show_bmp_mix("./quite.bmp",360,285,100,50);
                       // show_set.stat = 0;
                      //  show_set.lock = 0;

		return 0;
	}
	//
	i = list_seek(shead,new->x0,new->y0);
	
	//判断i的值，如果等于1
	if(i == 1)
	{
		return i;//程序退出，返回i
	}

	else//如果i的值不等于1
	{
		//将蛇头节点的下一个节点赋值给新节点的下一个节点
		new->next = shead->next;
		//蛇头界定啊赋值给新节点的上一个节点
		new->pre = shead;
		

		//将新节点赋值给蛇头节点的下一个的上一个节点
		shead->next->pre = new;
		//将新节点赋值给蛇头节点的下一个节点
		shead->next = new;			
	} 

	return i;		

}

/*********************************************************************************
函数功能：蛇前进的延时函数度函数
函数参数： shead：蛇头； fx：蛇头x坐标 ；  fy：蛇头y坐标
返回值：0
*********************************************************************************/
int list_delate(struct slink * shead,int *fx,int *fy)
{
	
	//新建一个蛇身节点，将蛇头的上一个节点赋值给它
	struct slink *tmp = shead->pre;
	
	//判断是否整个蛇身延迟
	if(tmp == shead){ //have been delated all 
		return -1;
	}
	
	*fx = tmp->x0;
	*fy = tmp->y0;
	
	//将新建节点的上一个节点赋值给蛇头节点的上一个节点
	shead->pre = tmp->pre;
	//蛇头节点赋值给新建节点的上一个节点的下一个节点
	tmp->pre->next = shead;
	
	//释放掉内存
	free(tmp);
	return 0;
}

/*********************************************************************************
函数功能：显示蛇图片函数
函数参数： shead：蛇头； 
返回值：无
*********************************************************************************/
void list_show(struct slink *shead)
{
	//新建一个结点，将蛇头结点赋值给它
	struct slink *tmp =shead;
	
	int i=0;

	//死循环
	while(1)
	{
		//将新建结点的下一个结点赋值给新建结点
		tmp = tmp->next;
		i++;
		//判断新建结点是否等于头节点
		if(tmp == shead)
		{
			//printf("list num:%d\n",i-1);
			break;//如果等于头节点，则退出
		}
		//如果头节点的下一个结点，等于新建结点
		if(tmp == shead->next)
		{
			show_bmp_mix("./h.bmp",tmp->x0,tmp->y0,20,20); //显示蛇头
		}
		else//如果头节点的下一个结点，不等于新建结点
		{
			show_bmp_mix("./s.bmp",tmp->x0,tmp->y0,20,20); //显示蛇身
		}
		
		usleep(1000*5);//延时5000毫秒
	}
	return;
}

/*********************************************************************************
函数功能：判断蛇到底是咋接走的
函数参数： shead：蛇头； sx蛇x坐标 ；  sy：蛇y坐标
返回值：0没有咬到自己身上   1咬到自己身上     2吃到食物
*********************************************************************************/
int list_seek(struct slink *shead,int sx,int sy)
{ //return value: 0 no touch self  1:touch self 2:eat food
	//新建一个结点，将蛇头结点赋值给它
	struct slink *tmp =shead;
	
	int i=0;

	while(1)
	{
		tmp = tmp->next;
		if(tmp == shead)
		{
			break;	
		}
			
		//如果蛇头咬到蛇身，返回1
		if(sx == tmp->x0&&sy == tmp->y0)
		{
			i = 1;
		}
		//如果蛇头咬到食物，返回2
		else if(sx == fxy.x0&&sy ==fxy.y0)
		{
			i = 2;
			score++;
			score_show();//蛇吃到食物之后，就要得分，调用得分显示函数
			fxy.x0 = -100;  // 初始化蛇的位置
			fxy.y0 = -100;
		}

	}	
	
	return i;
}
